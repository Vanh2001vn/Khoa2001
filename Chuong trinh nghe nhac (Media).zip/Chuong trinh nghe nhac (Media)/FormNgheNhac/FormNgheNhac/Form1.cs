﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormNgheNhac
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int vt = -1;

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
       //     axWindowsMediaPlayer1.URL = @"C:\Users\Public\Videos\Sample Videos\Wildlife.wmv";
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                axWindowsMediaPlayer1.URL = openFileDialog1.FileName;
                listbox1.Items.Clear();
                listbox1.Items.Add(openFileDialog1.FileName);
                vt = 0;
            }
              
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         //   axWindowsMediaPlayer1.URL = @"C:\Users\Public\Videos\Sample Videos\Wildlife.wmv";
        }
       
      //  string [] fileNames, filePaths;  //truyền nhiều file thì phải tạo mảng
        private void addMediaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int non = 0; //rỗng
            
            if(listbox1.Items.Count ==0)
            {
                non = 1; //ko có rỗng
            }
            if(openFileDialog2.ShowDialog()==DialogResult.OK)
            {
                listbox1.Items.Clear();
                foreach(string media in openFileDialog2.FileNames)
                {
                    
                    listbox1.Items.Add(media);
                   
                }
              
           /*     fileNames = openFileDialog2.SafeFileNames; //có "s" đằng sau là truyền nguyên 1 chuỗi
                filePaths = openFileDialog2.FileNames;
                
                foreach (string fileName in fileNames)
                {
                    listbox1.Items.Add(fileName);
                }
             */
            }

            if(axWindowsMediaPlayer1.status.Contains("Stop"))
            {
                axWindowsMediaPlayer1.URL = listbox1.Items[0].ToString();
                axWindowsMediaPlayer1.Ctlcontrols.play();
                axWindowsMediaPlayer1.Ctlcontrols.next();

            }
            if (non !=0)
            {
                axWindowsMediaPlayer1.URL = listbox1.Items[0].ToString();
            }

        }

        private void listbox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            vt = listbox1.SelectedIndex;
            axWindowsMediaPlayer1.URL = listbox1.Items[vt].ToString();
            axWindowsMediaPlayer1.Ctlcontrols.next();
         //  axWindowsMediaPlayer1.URL = filePaths[listbox1.SelectedIndex];
            //chọn 1 bài bất kì trong listbox thì nó sẽ tự động play
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        public bool isSound = true;
        private void soundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isSound = !isSound;
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }
    }
}
